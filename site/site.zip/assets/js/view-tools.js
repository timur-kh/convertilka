// Инструменты предпросмотра: поворот изображения/видео на 90° и покадровое перемещение по видео.
import { h } from './util.js';

const norm = (deg) => ((deg % 360) + 360) % 360;

/**
 * Кнопки «повернуть влево / вправо». Поворот хранится в edit.rotate (0, 90, 180, 270 — по часовой)
 * и применяется при конвертации. Предпросмотр поворачивается сразу — через CSS, без перекодирования.
 * target — <img> или <video>; onChange() — сообщить, что правки изменились.
 */
export function rotateControl(target, edit, onChange) {
  const label = h('span', { class: 'rot-label', 'aria-live': 'polite' });
  const btn = (dir, title, glyph) => {
    const b = h('button', { type: 'button', class: 'icon-btn rot-btn', title, 'aria-label': title }, glyph);
    b.addEventListener('click', () => {
      edit.rotate = norm((edit.rotate || 0) + dir * 90);
      apply();
      onChange?.();
    });
    return b;
  };
  const el = h('div', { class: 'rot-tools' }, btn(-1, 'Повернуть влево на 90°', '↺'), btn(1, 'Повернуть вправо на 90°', '↻'), label);

  function apply() {
    const deg = norm(edit.rotate || 0);
    // Повёрнутое на 90° изображение должно поместиться в тот же прямоугольник: уменьшаем пропорционально
    const w = target.offsetWidth, hh = target.offsetHeight;
    const k = deg % 180 && w && hh ? Math.min(w / hh, hh / w) : 1;
    target.style.transform = deg ? `rotate(${deg}deg) scale(${k})` : '';
    label.textContent = deg ? `повёрнуто на ${deg}°` : '';
    label.hidden = !deg;
  }
  // Размеры элемента известны только после загрузки
  target.addEventListener('load', apply);
  target.addEventListener('loadedmetadata', apply);
  const ro = new ResizeObserver(apply);
  ro.observe(target);
  apply();
  return { el, apply, dispose: () => ro.disconnect() };
}

/**
 * Простая панель «▶ / ⏸ + полоса времени» — вместо встроенных кнопок плеера, когда видео повёрнуто
 * (встроенные кнопки поворачиваются вместе с видео и становятся неудобными).
 */
export function playBar(player) {
  const btn = h('button', { type: 'button', class: 'icon-btn play-btn', 'aria-label': 'Воспроизвести' }, '▶');
  const range = h('input', { type: 'range', class: 'play-range', min: '0', max: '1000', value: '0', 'aria-label': 'Позиция в видео' });
  btn.addEventListener('click', () => (player.paused ? player.play().catch(() => {}) : player.pause()));
  const sync = () => {
    btn.textContent = player.paused ? '▶' : '⏸';
    btn.setAttribute('aria-label', player.paused ? 'Воспроизвести' : 'Пауза');
    if (document.activeElement !== range && player.duration) range.value = String(Math.round((player.currentTime / player.duration) * 1000));
  };
  range.addEventListener('input', () => player.duration && (player.currentTime = (range.value / 1000) * player.duration));
  for (const ev of ['play', 'pause', 'timeupdate', 'seeked', 'loadedmetadata']) player.addEventListener(ev, sync);
  return { el: h('div', { class: 'play-bar' }, btn, range) };
}

const fmtTime = (t) => {
  const m = Math.floor(t / 60), s = t - m * 60;
  return `${m}:${s.toFixed(2).padStart(5, '0')}`;
};

/**
 * Покадровое перемещение: «‹ кадр», «кадр ›» и клавиши «,» / «.» (как в YouTube).
 * getFps() — частота кадров (известна после чтения файла; до этого — 30).
 */
export function frameStepper(player, getFps) {
  const info = h('span', { class: 'frame-info' }, 'кадр 1');
  const step = (dir) => {
    const fps = getFps() || 30;
    player.pause();
    const dur = Number.isFinite(player.duration) ? player.duration : Infinity;
    // Встаём в середину нужного кадра — так браузер не промахивается на границе соседних кадров
    const frame = Math.max(0, frameOf(player.currentTime, fps) + dir);
    player.currentTime = Math.min(dur - 0.5 / fps, (frame + 0.5) / fps);
  };
  const frameOf = (t, fps) => Math.floor(t * fps + 1e-6);
  const update = () => {
    const fps = getFps() || 30;
    info.textContent = `кадр ${frameOf(player.currentTime, fps) + 1} · ${fmtTime(player.currentTime)}`;
  };
  const btn = (dir, text, title) => {
    const b = h('button', { type: 'button', class: 'btn btn-ghost btn-sm frame-btn', title, 'aria-label': title }, text);
    b.addEventListener('click', () => step(dir));
    return b;
  };
  const el = h('div', { class: 'frame-tools' },
    btn(-1, '‹ кадр', 'Предыдущий кадр (клавиша ,)'),
    info,
    btn(1, 'кадр ›', 'Следующий кадр (клавиша .)'));
  player.addEventListener('seeked', update);
  player.addEventListener('timeupdate', update);
  player.addEventListener('loadedmetadata', update);
  const onKey = (e) => {
    if (e.target.closest?.('input, textarea, select, [contenteditable="true"]') || e.ctrlKey || e.metaKey || e.altKey) return;
    if (!player.isConnected) return;
    if (e.key === ',' || e.key === 'б') { e.preventDefault(); step(-1); }
    else if (e.key === '.' || e.key === 'ю') { e.preventDefault(); step(1); }
  };
  document.addEventListener('keydown', onKey);
  return { el, update, dispose: () => document.removeEventListener('keydown', onKey) };
}
